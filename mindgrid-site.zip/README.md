# MindGrid — Deployment Guide

## What changed from the artifact version
The two `fetch()` calls in `src/MindGrid.jsx` now hit `/.netlify/functions/negotiate`
instead of `https://api.anthropic.com/v1/messages` directly. That serverless
function (`netlify/functions/negotiate.js`) holds your Anthropic API key and
forwards the request — the key never reaches the browser.

## 1. Get an Anthropic API key
console.anthropic.com → Settings → API Keys → Create Key.

## 2. Push this folder to GitHub
```
cd mindgrid-site
git init
git add .
git commit -m "MindGrid initial commit"
git branch -M main
git remote add origin https://github.com/<your-username>/mindgrid.git
git push -u origin main
```

## 3. Connect to Netlify
1. netlify.com → Add new site → Import an existing project → pick the GitHub repo.
2. Build command: `npm run build` (already set in netlify.toml, Netlify will detect it).
3. Publish directory: `dist` (already set).
4. Deploy site.

## 4. Add your API key to Netlify
Site settings → Environment variables → Add a variable:
- Key: `ANTHROPIC_API_KEY`
- Value: your key from step 1

Then trigger a redeploy (Deploys → Trigger deploy) so the function picks it up.

## 5. Test it live
Open the Netlify URL, pick a mode, negotiate with a guardian. If a character's
reply always falls back to the generic lines ("...fine, it's yours"), the
function call is failing — check Netlify's function logs (Site → Functions →
negotiate → Logs) for the actual error, usually a missing/incorrect API key.

## Local development
```
npm install
npx netlify dev
```
`netlify dev` (not `npm run dev`) runs both the Vite frontend AND the
serverless function locally, so negotiation works on localhost too. Plain
`npm run dev` will run the site but the AI calls will 404, since there's no
function server behind them.

## Optional: custom domain / GitHub Pages
GitHub Pages can't run the serverless function (it's static-only), so it
can't host this as-is. Netlify (or Vercel, with the same idea using a
`/api` route instead of `/.netlify/functions`) is the right home for this
one, unlike Bunkometer which needed no backend at all.
